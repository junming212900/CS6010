//
//  cmdline.hpp
//  HW1
//
//  Created by junming jin on 1/18/23.
//

#ifndef cmdline_hpp
#define cmdline_hpp

#include <stdio.h>
int use_arguments(int argc, const char * argv[]);

#endif /* cmdline_hpp */
