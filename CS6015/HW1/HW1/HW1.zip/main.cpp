//
//  main.cpp
//  HW1
//
//  Created by junming jin on 1/18/23.
//

#include <iostream>
#include "cmdline.hpp"

int main(int argc, const char * argv[]) {
    
    use_arguments(argc, argv);
    return 0;
}


